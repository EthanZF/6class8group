# 为 Article 增加「置顶」与「精选」两个标记字段，并把置顶排到列表最前
from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('blog', '0008_blogsettings_color_scheme'),
    ]

    operations = [
        migrations.AddField(
            model_name='article',
            name='is_top',
            field=models.BooleanField(
                db_index=True,
                default=False,
                help_text='勾选后该文章在文章列表里排在最前面',
                verbose_name='置顶',
            ),
        ),
        migrations.AddField(
            model_name='article',
            name='is_featured',
            field=models.BooleanField(
                db_index=True,
                default=False,
                help_text='勾选后该文章会出现在首页的精选区域',
                verbose_name='精选',
            ),
        ),
        migrations.AlterModelOptions(
            name='article',
            options={
                'get_latest_by': 'id',
                'ordering': ['-is_top', '-article_order', '-pub_time'],
                'verbose_name': 'article',
                'verbose_name_plural': 'article',
            },
        ),
    ]
